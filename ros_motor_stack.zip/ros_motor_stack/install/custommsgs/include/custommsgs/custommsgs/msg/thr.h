// generated from rosidl_generator_c/resource/idl.h.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__THR_H_
#define CUSTOMMSGS__MSG__THR_H_

#include "custommsgs/msg/detail/thr__struct.h"
#include "custommsgs/msg/detail/thr__functions.h"
#include "custommsgs/msg/detail/thr__type_support.h"

#endif  // CUSTOMMSGS__MSG__THR_H_
