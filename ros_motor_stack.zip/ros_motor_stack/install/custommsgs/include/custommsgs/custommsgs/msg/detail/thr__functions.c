// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice
#include "custommsgs/msg/detail/thr__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
custommsgs__msg__Thr__init(custommsgs__msg__Thr * msg)
{
  if (!msg) {
    return false;
  }
  // left_thr
  // right_thr
  return true;
}

void
custommsgs__msg__Thr__fini(custommsgs__msg__Thr * msg)
{
  if (!msg) {
    return;
  }
  // left_thr
  // right_thr
}

bool
custommsgs__msg__Thr__are_equal(const custommsgs__msg__Thr * lhs, const custommsgs__msg__Thr * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // left_thr
  if (lhs->left_thr != rhs->left_thr) {
    return false;
  }
  // right_thr
  if (lhs->right_thr != rhs->right_thr) {
    return false;
  }
  return true;
}

bool
custommsgs__msg__Thr__copy(
  const custommsgs__msg__Thr * input,
  custommsgs__msg__Thr * output)
{
  if (!input || !output) {
    return false;
  }
  // left_thr
  output->left_thr = input->left_thr;
  // right_thr
  output->right_thr = input->right_thr;
  return true;
}

custommsgs__msg__Thr *
custommsgs__msg__Thr__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  custommsgs__msg__Thr * msg = (custommsgs__msg__Thr *)allocator.allocate(sizeof(custommsgs__msg__Thr), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(custommsgs__msg__Thr));
  bool success = custommsgs__msg__Thr__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
custommsgs__msg__Thr__destroy(custommsgs__msg__Thr * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    custommsgs__msg__Thr__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
custommsgs__msg__Thr__Sequence__init(custommsgs__msg__Thr__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  custommsgs__msg__Thr * data = NULL;

  if (size) {
    data = (custommsgs__msg__Thr *)allocator.zero_allocate(size, sizeof(custommsgs__msg__Thr), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = custommsgs__msg__Thr__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        custommsgs__msg__Thr__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
custommsgs__msg__Thr__Sequence__fini(custommsgs__msg__Thr__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      custommsgs__msg__Thr__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

custommsgs__msg__Thr__Sequence *
custommsgs__msg__Thr__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  custommsgs__msg__Thr__Sequence * array = (custommsgs__msg__Thr__Sequence *)allocator.allocate(sizeof(custommsgs__msg__Thr__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = custommsgs__msg__Thr__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
custommsgs__msg__Thr__Sequence__destroy(custommsgs__msg__Thr__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    custommsgs__msg__Thr__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
custommsgs__msg__Thr__Sequence__are_equal(const custommsgs__msg__Thr__Sequence * lhs, const custommsgs__msg__Thr__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!custommsgs__msg__Thr__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
custommsgs__msg__Thr__Sequence__copy(
  const custommsgs__msg__Thr__Sequence * input,
  custommsgs__msg__Thr__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(custommsgs__msg__Thr);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    custommsgs__msg__Thr * data =
      (custommsgs__msg__Thr *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!custommsgs__msg__Thr__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          custommsgs__msg__Thr__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!custommsgs__msg__Thr__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
