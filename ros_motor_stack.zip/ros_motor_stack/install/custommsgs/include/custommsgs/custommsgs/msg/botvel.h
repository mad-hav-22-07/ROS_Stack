// generated from rosidl_generator_c/resource/idl.h.em
// with input from custommsgs:msg/Botvel.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__BOTVEL_H_
#define CUSTOMMSGS__MSG__BOTVEL_H_

#include "custommsgs/msg/detail/botvel__struct.h"
#include "custommsgs/msg/detail/botvel__functions.h"
#include "custommsgs/msg/detail/botvel__type_support.h"

#endif  // CUSTOMMSGS__MSG__BOTVEL_H_
