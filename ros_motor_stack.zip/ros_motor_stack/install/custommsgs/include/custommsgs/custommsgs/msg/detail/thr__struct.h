// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_H_
#define CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Thr in the package custommsgs.
typedef struct custommsgs__msg__Thr
{
  float left_thr;
  float right_thr;
} custommsgs__msg__Thr;

// Struct for a sequence of custommsgs__msg__Thr.
typedef struct custommsgs__msg__Thr__Sequence
{
  custommsgs__msg__Thr * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custommsgs__msg__Thr__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_H_
