// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__THR__BUILDER_HPP_
#define CUSTOMMSGS__MSG__DETAIL__THR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custommsgs/msg/detail/thr__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custommsgs
{

namespace msg
{

namespace builder
{

class Init_Thr_right_thr
{
public:
  explicit Init_Thr_right_thr(::custommsgs::msg::Thr & msg)
  : msg_(msg)
  {}
  ::custommsgs::msg::Thr right_thr(::custommsgs::msg::Thr::_right_thr_type arg)
  {
    msg_.right_thr = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custommsgs::msg::Thr msg_;
};

class Init_Thr_left_thr
{
public:
  Init_Thr_left_thr()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Thr_right_thr left_thr(::custommsgs::msg::Thr::_left_thr_type arg)
  {
    msg_.left_thr = std::move(arg);
    return Init_Thr_right_thr(msg_);
  }

private:
  ::custommsgs::msg::Thr msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custommsgs::msg::Thr>()
{
  return custommsgs::msg::builder::Init_Thr_left_thr();
}

}  // namespace custommsgs

#endif  // CUSTOMMSGS__MSG__DETAIL__THR__BUILDER_HPP_
