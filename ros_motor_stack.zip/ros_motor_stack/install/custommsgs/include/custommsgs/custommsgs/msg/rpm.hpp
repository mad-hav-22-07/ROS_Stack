// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__RPM_HPP_
#define CUSTOMMSGS__MSG__RPM_HPP_

#include "custommsgs/msg/detail/rpm__struct.hpp"
#include "custommsgs/msg/detail/rpm__builder.hpp"
#include "custommsgs/msg/detail/rpm__traits.hpp"
#include "custommsgs/msg/detail/rpm__type_support.hpp"

#endif  // CUSTOMMSGS__MSG__RPM_HPP_
