// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custommsgs:msg/Botvel.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__BOTVEL__BUILDER_HPP_
#define CUSTOMMSGS__MSG__DETAIL__BOTVEL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custommsgs/msg/detail/botvel__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custommsgs
{

namespace msg
{

namespace builder
{

class Init_Botvel_w
{
public:
  explicit Init_Botvel_w(::custommsgs::msg::Botvel & msg)
  : msg_(msg)
  {}
  ::custommsgs::msg::Botvel w(::custommsgs::msg::Botvel::_w_type arg)
  {
    msg_.w = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custommsgs::msg::Botvel msg_;
};

class Init_Botvel_x_vel
{
public:
  Init_Botvel_x_vel()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Botvel_w x_vel(::custommsgs::msg::Botvel::_x_vel_type arg)
  {
    msg_.x_vel = std::move(arg);
    return Init_Botvel_w(msg_);
  }

private:
  ::custommsgs::msg::Botvel msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custommsgs::msg::Botvel>()
{
  return custommsgs::msg::builder::Init_Botvel_x_vel();
}

}  // namespace custommsgs

#endif  // CUSTOMMSGS__MSG__DETAIL__BOTVEL__BUILDER_HPP_
