// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custommsgs:msg/Rpm.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__RPM__BUILDER_HPP_
#define CUSTOMMSGS__MSG__DETAIL__RPM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custommsgs/msg/detail/rpm__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custommsgs
{

namespace msg
{

namespace builder
{

class Init_Rpm_right_enc
{
public:
  explicit Init_Rpm_right_enc(::custommsgs::msg::Rpm & msg)
  : msg_(msg)
  {}
  ::custommsgs::msg::Rpm right_enc(::custommsgs::msg::Rpm::_right_enc_type arg)
  {
    msg_.right_enc = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custommsgs::msg::Rpm msg_;
};

class Init_Rpm_left_enc
{
public:
  Init_Rpm_left_enc()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Rpm_right_enc left_enc(::custommsgs::msg::Rpm::_left_enc_type arg)
  {
    msg_.left_enc = std::move(arg);
    return Init_Rpm_right_enc(msg_);
  }

private:
  ::custommsgs::msg::Rpm msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custommsgs::msg::Rpm>()
{
  return custommsgs::msg::builder::Init_Rpm_left_enc();
}

}  // namespace custommsgs

#endif  // CUSTOMMSGS__MSG__DETAIL__RPM__BUILDER_HPP_
