// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from custommsgs:msg/Botvel.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__BOTVEL__TRAITS_HPP_
#define CUSTOMMSGS__MSG__DETAIL__BOTVEL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "custommsgs/msg/detail/botvel__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace custommsgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Botvel & msg,
  std::ostream & out)
{
  out << "{";
  // member: x_vel
  {
    out << "x_vel: ";
    rosidl_generator_traits::value_to_yaml(msg.x_vel, out);
    out << ", ";
  }

  // member: w
  {
    out << "w: ";
    rosidl_generator_traits::value_to_yaml(msg.w, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Botvel & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: x_vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x_vel: ";
    rosidl_generator_traits::value_to_yaml(msg.x_vel, out);
    out << "\n";
  }

  // member: w
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "w: ";
    rosidl_generator_traits::value_to_yaml(msg.w, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Botvel & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace custommsgs

namespace rosidl_generator_traits
{

[[deprecated("use custommsgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const custommsgs::msg::Botvel & msg,
  std::ostream & out, size_t indentation = 0)
{
  custommsgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use custommsgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const custommsgs::msg::Botvel & msg)
{
  return custommsgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<custommsgs::msg::Botvel>()
{
  return "custommsgs::msg::Botvel";
}

template<>
inline const char * name<custommsgs::msg::Botvel>()
{
  return "custommsgs/msg/Botvel";
}

template<>
struct has_fixed_size<custommsgs::msg::Botvel>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<custommsgs::msg::Botvel>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<custommsgs::msg::Botvel>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CUSTOMMSGS__MSG__DETAIL__BOTVEL__TRAITS_HPP_
