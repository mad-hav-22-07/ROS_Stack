// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_HPP_
#define CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__custommsgs__msg__Thr __attribute__((deprecated))
#else
# define DEPRECATED__custommsgs__msg__Thr __declspec(deprecated)
#endif

namespace custommsgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Thr_
{
  using Type = Thr_<ContainerAllocator>;

  explicit Thr_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_thr = 0.0f;
      this->right_thr = 0.0f;
    }
  }

  explicit Thr_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_thr = 0.0f;
      this->right_thr = 0.0f;
    }
  }

  // field types and members
  using _left_thr_type =
    float;
  _left_thr_type left_thr;
  using _right_thr_type =
    float;
  _right_thr_type right_thr;

  // setters for named parameter idiom
  Type & set__left_thr(
    const float & _arg)
  {
    this->left_thr = _arg;
    return *this;
  }
  Type & set__right_thr(
    const float & _arg)
  {
    this->right_thr = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    custommsgs::msg::Thr_<ContainerAllocator> *;
  using ConstRawPtr =
    const custommsgs::msg::Thr_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<custommsgs::msg::Thr_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<custommsgs::msg::Thr_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      custommsgs::msg::Thr_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<custommsgs::msg::Thr_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      custommsgs::msg::Thr_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<custommsgs::msg::Thr_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<custommsgs::msg::Thr_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<custommsgs::msg::Thr_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__custommsgs__msg__Thr
    std::shared_ptr<custommsgs::msg::Thr_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__custommsgs__msg__Thr
    std::shared_ptr<custommsgs::msg::Thr_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Thr_ & other) const
  {
    if (this->left_thr != other.left_thr) {
      return false;
    }
    if (this->right_thr != other.right_thr) {
      return false;
    }
    return true;
  }
  bool operator!=(const Thr_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Thr_

// alias to use template instance with default allocator
using Thr =
  custommsgs::msg::Thr_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace custommsgs

#endif  // CUSTOMMSGS__MSG__DETAIL__THR__STRUCT_HPP_
