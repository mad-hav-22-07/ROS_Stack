// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__BOTVEL_HPP_
#define CUSTOMMSGS__MSG__BOTVEL_HPP_

#include "custommsgs/msg/detail/botvel__struct.hpp"
#include "custommsgs/msg/detail/botvel__builder.hpp"
#include "custommsgs/msg/detail/botvel__traits.hpp"
#include "custommsgs/msg/detail/botvel__type_support.hpp"

#endif  // CUSTOMMSGS__MSG__BOTVEL_HPP_
