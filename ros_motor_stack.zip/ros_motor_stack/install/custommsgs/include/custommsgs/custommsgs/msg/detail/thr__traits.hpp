// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from custommsgs:msg/Thr.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__DETAIL__THR__TRAITS_HPP_
#define CUSTOMMSGS__MSG__DETAIL__THR__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "custommsgs/msg/detail/thr__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace custommsgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Thr & msg,
  std::ostream & out)
{
  out << "{";
  // member: left_thr
  {
    out << "left_thr: ";
    rosidl_generator_traits::value_to_yaml(msg.left_thr, out);
    out << ", ";
  }

  // member: right_thr
  {
    out << "right_thr: ";
    rosidl_generator_traits::value_to_yaml(msg.right_thr, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Thr & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: left_thr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_thr: ";
    rosidl_generator_traits::value_to_yaml(msg.left_thr, out);
    out << "\n";
  }

  // member: right_thr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_thr: ";
    rosidl_generator_traits::value_to_yaml(msg.right_thr, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Thr & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace custommsgs

namespace rosidl_generator_traits
{

[[deprecated("use custommsgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const custommsgs::msg::Thr & msg,
  std::ostream & out, size_t indentation = 0)
{
  custommsgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use custommsgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const custommsgs::msg::Thr & msg)
{
  return custommsgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<custommsgs::msg::Thr>()
{
  return "custommsgs::msg::Thr";
}

template<>
inline const char * name<custommsgs::msg::Thr>()
{
  return "custommsgs/msg/Thr";
}

template<>
struct has_fixed_size<custommsgs::msg::Thr>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<custommsgs::msg::Thr>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<custommsgs::msg::Thr>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CUSTOMMSGS__MSG__DETAIL__THR__TRAITS_HPP_
