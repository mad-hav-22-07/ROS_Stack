// generated from rosidl_generator_c/resource/idl.h.em
// with input from custommsgs:msg/Rpm.idl
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__RPM_H_
#define CUSTOMMSGS__MSG__RPM_H_

#include "custommsgs/msg/detail/rpm__struct.h"
#include "custommsgs/msg/detail/rpm__functions.h"
#include "custommsgs/msg/detail/rpm__type_support.h"

#endif  // CUSTOMMSGS__MSG__RPM_H_
