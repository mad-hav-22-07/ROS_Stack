// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOMMSGS__MSG__THR_HPP_
#define CUSTOMMSGS__MSG__THR_HPP_

#include "custommsgs/msg/detail/thr__struct.hpp"
#include "custommsgs/msg/detail/thr__builder.hpp"
#include "custommsgs/msg/detail/thr__traits.hpp"
#include "custommsgs/msg/detail/thr__type_support.hpp"

#endif  // CUSTOMMSGS__MSG__THR_HPP_
