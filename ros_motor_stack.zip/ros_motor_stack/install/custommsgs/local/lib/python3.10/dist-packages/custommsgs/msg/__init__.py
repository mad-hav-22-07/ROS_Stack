from custommsgs.msg._botvel import Botvel  # noqa: F401
from custommsgs.msg._rpm import Rpm  # noqa: F401
from custommsgs.msg._thr import Thr  # noqa: F401
